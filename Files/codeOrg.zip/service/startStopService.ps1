Function startStop {

    If ((Get-Service CodeOrganizer).Status -ne 'Running') { 
        Start-Service CodeOrganizer
        Clear-Host
        Write-Host "Starting CodeOrganizer Service.."
        Start-Sleep -Seconds 3
        exitFunk
    } ELSE { 
        Stop-Service CodeOrganizer
        Clear-Host
        Write-Host "Stopping CodeOrganizer Service.."
        Start-Sleep -Seconds 3
        exitFunk
    }

}

Function exitFunk {
    Exit
}

#-----Start Script----#
$Title = "Start/Stop CodeOrganizer Service"
$host.UI.RawUI.WindowTitle = $Title

#Set the windows size
Function Set-WindowSize {
Param([int]$ConWidth=$host.ui.rawui.windowsize.width,
      [int]$ConHeight=$host.ui.rawui.windowsize.heigth)

    $size=New-Object System.Management.Automation.Host.Size($ConWidth,$ConHeight)
    $host.ui.rawui.WindowSize=$size  
}
Set-WindowSize 55 12 *>$null

Clear-Host
startStop