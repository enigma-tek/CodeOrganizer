# Summary

Date : 2025-07-22 11:40:45

Directory c:\\Program Files\\Enigma-Tek\\codeOrg

Total : 94 files,  62306 codes, 93 comments, 1056 blanks, all 63455 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Log | 48 | 60,166 | 0 | 189 | 60,355 |
| PowerShell | 29 | 1,912 | 93 | 806 | 2,811 |
| HTML | 2 | 125 | 0 | 42 | 167 |
| JSON | 14 | 84 | 0 | 13 | 97 |
| PostCSS | 1 | 19 | 0 | 6 | 25 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 94 | 62,306 | 93 | 1,056 | 63,455 |
| . (Files) | 2 | 53 | 29 | 27 | 109 |
| arc | 2 | 13 | 0 | 2 | 15 |
| arc\\cmd | 1 | 9 | 0 | 1 | 10 |
| arc\\cmd\\07.14.2025_10.10.21_Get-ThisJunk | 1 | 9 | 0 | 1 | 10 |
| arc\\sql | 1 | 4 | 0 | 1 | 5 |
| arc\\sql\\07.12.2025_08.36.46_sdfgsdfgsdfg | 1 | 4 | 0 | 1 | 5 |
| files | 16 | 287 | 14 | 93 | 394 |
| files\\commands | 4 | 28 | 0 | 4 | 32 |
| files\\commands\\full | 2 | 18 | 0 | 2 | 20 |
| files\\commands\\tbl | 2 | 10 | 0 | 2 | 12 |
| files\\configs | 2 | 4 | 0 | 1 | 5 |
| files\\kql | 1 | 4 | 0 | 1 | 5 |
| files\\kql\\kqlMeta | 1 | 4 | 0 | 1 | 5 |
| files\\powershell | 8 | 247 | 14 | 86 | 347 |
| files\\powershell\\scripts | 2 | 91 | 14 | 40 | 145 |
| files\\powershell\\scriptsHTML | 2 | 125 | 0 | 42 | 167 |
| files\\powershell\\scriptsMeta | 2 | 18 | 0 | 2 | 20 |
| files\\powershell\\snippetsMeta | 2 | 13 | 0 | 2 | 15 |
| files\\sql | 1 | 4 | 0 | 1 | 5 |
| files\\sql\\sqlMeta | 1 | 4 | 0 | 1 | 5 |
| logs | 48 | 60,166 | 0 | 189 | 60,355 |
| logs\\errors | 8 | 1,494 | 0 | 149 | 1,643 |
| logs\\requests | 40 | 58,672 | 0 | 40 | 58,712 |
| modules | 2 | 262 | 21 | 150 | 433 |
| pages | 23 | 1,506 | 29 | 589 | 2,124 |
| public | 1 | 19 | 0 | 6 | 25 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)