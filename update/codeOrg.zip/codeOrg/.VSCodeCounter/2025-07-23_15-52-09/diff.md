# Diff Summary

Date : 2025-07-23 15:52:09

Directory c:\\Program Files\\Enigma-Tek\\codeOrg

Total : 26 files,  4941 codes, -6 comments, 40 blanks, all 4975 lines

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Log | 4 | 5,123 | 0 | 118 | 5,241 |
| PostCSS | 1 | 3 | 0 | 0 | 3 |
| JSON | 13 | -8 | 0 | -1 | -9 |
| PowerShell | 7 | -84 | -6 | -42 | -132 |
| HTML | 1 | -93 | 0 | -35 | -128 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 26 | 4,941 | -6 | 40 | 4,975 |
| arc | 2 | -13 | 0 | -2 | -15 |
| arc\\cmd | 1 | -9 | 0 | -1 | -10 |
| arc\\cmd\\07.14.2025_10.10.21_Get-ThisJunk | 1 | -9 | 0 | -1 | -10 |
| arc\\sql | 1 | -4 | 0 | -1 | -5 |
| arc\\sql\\07.12.2025_08.36.46_sdfgsdfgsdfg | 1 | -4 | 0 | -1 | -5 |
| files | 13 | -165 | -6 | -68 | -239 |
| files\\commands | 10 | 14 | 0 | 2 | 16 |
| files\\commands\\full | 5 | 9 | 0 | 1 | 10 |
| files\\commands\\tbl | 5 | 5 | 0 | 1 | 6 |
| files\\powershell | 3 | -179 | -6 | -70 | -255 |
| files\\powershell\\scripts | 1 | -77 | -6 | -34 | -117 |
| files\\powershell\\scriptsHTML | 1 | -93 | 0 | -35 | -128 |
| files\\powershell\\scriptsMeta | 1 | -9 | 0 | -1 | -10 |
| logs | 4 | 5,123 | 0 | 118 | 5,241 |
| logs\\errors | 2 | 1,199 | 0 | 117 | 1,316 |
| logs\\requests | 2 | 3,924 | 0 | 1 | 3,925 |
| modules | 2 | -9 | 0 | -8 | -17 |
| pages | 4 | 2 | 0 | 0 | 2 |
| public | 1 | 3 | 0 | 0 | 3 |

[Summary](results.md) / [Details](details.md) / Diff Summary / [Diff Details](diff-details.md)