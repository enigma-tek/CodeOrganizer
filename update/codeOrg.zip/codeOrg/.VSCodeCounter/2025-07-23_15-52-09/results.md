# Summary

Date : 2025-07-23 15:52:09

Directory c:\\Program Files\\Enigma-Tek\\codeOrg

Total : 93 files,  67247 codes, 87 comments, 1096 blanks, all 68430 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| Log | 50 | 65,289 | 0 | 307 | 65,596 |
| PowerShell | 28 | 1,828 | 87 | 764 | 2,679 |
| JSON | 13 | 76 | 0 | 12 | 88 |
| HTML | 1 | 32 | 0 | 7 | 39 |
| PostCSS | 1 | 22 | 0 | 6 | 28 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 93 | 67,247 | 87 | 1,096 | 68,430 |
| . (Files) | 2 | 53 | 29 | 27 | 109 |
| files | 15 | 122 | 8 | 25 | 155 |
| files\\commands | 6 | 42 | 0 | 6 | 48 |
| files\\commands\\full | 3 | 27 | 0 | 3 | 30 |
| files\\commands\\tbl | 3 | 15 | 0 | 3 | 18 |
| files\\configs | 2 | 4 | 0 | 1 | 5 |
| files\\kql | 1 | 4 | 0 | 1 | 5 |
| files\\kql\\kqlMeta | 1 | 4 | 0 | 1 | 5 |
| files\\powershell | 5 | 68 | 8 | 16 | 92 |
| files\\powershell\\scripts | 1 | 14 | 8 | 6 | 28 |
| files\\powershell\\scriptsHTML | 1 | 32 | 0 | 7 | 39 |
| files\\powershell\\scriptsMeta | 1 | 9 | 0 | 1 | 10 |
| files\\powershell\\snippetsMeta | 2 | 13 | 0 | 2 | 15 |
| files\\sql | 1 | 4 | 0 | 1 | 5 |
| files\\sql\\sqlMeta | 1 | 4 | 0 | 1 | 5 |
| logs | 50 | 65,289 | 0 | 307 | 65,596 |
| logs\\errors | 9 | 2,693 | 0 | 266 | 2,959 |
| logs\\requests | 41 | 62,596 | 0 | 41 | 62,637 |
| modules | 2 | 253 | 21 | 142 | 416 |
| pages | 23 | 1,508 | 29 | 589 | 2,126 |
| public | 1 | 22 | 0 | 6 | 28 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)