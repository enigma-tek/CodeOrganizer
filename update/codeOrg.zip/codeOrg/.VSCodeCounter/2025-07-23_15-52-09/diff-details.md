# Diff Details

Date : 2025-07-23 15:52:09

Directory c:\\Program Files\\Enigma-Tek\\codeOrg

Total : 26 files,  4941 codes, -6 comments, 40 blanks, all 4975 lines

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [arc/cmd/07.14.2025\_10.10.21\_Get-ThisJunk/Get-ThisJunk.json](/arc/cmd/07.14.2025_10.10.21_Get-ThisJunk/Get-ThisJunk.json) | JSON | -9 | 0 | -1 | -10 |
| [arc/sql/07.12.2025\_08.36.46\_sdfgsdfgsdfg/sdfgsdfgsdfg.json](/arc/sql/07.12.2025_08.36.46_sdfgsdfgsdfg/sdfgsdfgsdfg.json) | JSON | -4 | 0 | -1 | -5 |
| [files/commands/full/Det-PodeWebStuff3.json](/files/commands/full/Det-PodeWebStuff3.json) | JSON | -9 | 0 | -1 | -10 |
| [files/commands/full/Get-AzApplicationGateway.json](/files/commands/full/Get-AzApplicationGateway.json) | JSON | 9 | 0 | 1 | 10 |
| [files/commands/full/Get-AzApplicationGateway1.json](/files/commands/full/Get-AzApplicationGateway1.json) | JSON | 9 | 0 | 1 | 10 |
| [files/commands/full/Get-ThisJunk44.json](/files/commands/full/Get-ThisJunk44.json) | JSON | -9 | 0 | -1 | -10 |
| [files/commands/full/hgkghkj.json](/files/commands/full/hgkghkj.json) | JSON | 9 | 0 | 1 | 10 |
| [files/commands/tbl/Det-PodeWebStuff3.json](/files/commands/tbl/Det-PodeWebStuff3.json) | JSON | -5 | 0 | -1 | -6 |
| [files/commands/tbl/Get-AzApplicationGateway.json](/files/commands/tbl/Get-AzApplicationGateway.json) | JSON | 5 | 0 | 1 | 6 |
| [files/commands/tbl/Get-AzApplicationGateway1.json](/files/commands/tbl/Get-AzApplicationGateway1.json) | JSON | 5 | 0 | 1 | 6 |
| [files/commands/tbl/Get-ThisJunk44.json](/files/commands/tbl/Get-ThisJunk44.json) | JSON | -5 | 0 | -1 | -6 |
| [files/commands/tbl/hgkghkj.json](/files/commands/tbl/hgkghkj.json) | JSON | 5 | 0 | 1 | 6 |
| [files/powershell/scriptsHTML/Testing.html](/files/powershell/scriptsHTML/Testing.html) | HTML | -93 | 0 | -35 | -128 |
| [files/powershell/scriptsMeta/Testing.json](/files/powershell/scriptsMeta/Testing.json) | JSON | -9 | 0 | -1 | -10 |
| [files/powershell/scripts/Testing.ps1](/files/powershell/scripts/Testing.ps1) | PowerShell | -77 | -6 | -34 | -117 |
| [logs/errors/psCodeOrg\_errors\_2025-07-22\_001.log](/logs/errors/psCodeOrg_errors_2025-07-22_001.log) | Log | 1,178 | 0 | 114 | 1,292 |
| [logs/errors/psCodeOrg\_errors\_2025-07-23\_001.log](/logs/errors/psCodeOrg_errors_2025-07-23_001.log) | Log | 21 | 0 | 3 | 24 |
| [logs/requests/psCodeOrg\_requests\_2025-07-22\_001.log](/logs/requests/psCodeOrg_requests_2025-07-22_001.log) | Log | 1,082 | 0 | 0 | 1,082 |
| [logs/requests/psCodeOrg\_requests\_2025-07-23\_001.log](/logs/requests/psCodeOrg_requests_2025-07-23_001.log) | Log | 2,842 | 0 | 1 | 2,843 |
| [modules/Module\_Modals.ps1](/modules/Module_Modals.ps1) | PowerShell | -4 | 0 | -4 | -8 |
| [modules/Module\_Tools.ps1](/modules/Module_Tools.ps1) | PowerShell | -5 | 0 | -4 | -9 |
| [pages/Page\_Home.ps1](/pages/Page_Home.ps1) | PowerShell | -1 | 0 | 0 | -1 |
| [pages/Page\_Oops.ps1](/pages/Page_Oops.ps1) | PowerShell | 2 | 0 | -1 | 1 |
| [pages/Page\_codeHub.ps1](/pages/Page_codeHub.ps1) | PowerShell | 0 | 0 | 1 | 1 |
| [pages/Page\_commandUpdate.ps1](/pages/Page_commandUpdate.ps1) | PowerShell | 1 | 0 | 0 | 1 |
| [public/style.css](/public/style.css) | PostCSS | 3 | 0 | 0 | 3 |

[Summary](results.md) / [Details](details.md) / [Diff Summary](diff.md) / Diff Details