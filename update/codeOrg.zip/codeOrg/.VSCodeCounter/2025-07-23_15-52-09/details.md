# Details

Date : 2025-07-23 15:52:09

Directory c:\\Program Files\\Enigma-Tek\\codeOrg

Total : 93 files,  67247 codes, 87 comments, 1096 blanks, all 68430 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [codeOrg.ps1](/codeOrg.ps1) | PowerShell | 24 | 29 | 26 | 79 |
| [files/commands/full/Get-AzApplicationGateway.json](/files/commands/full/Get-AzApplicationGateway.json) | JSON | 9 | 0 | 1 | 10 |
| [files/commands/full/Get-AzApplicationGateway1.json](/files/commands/full/Get-AzApplicationGateway1.json) | JSON | 9 | 0 | 1 | 10 |
| [files/commands/full/hgkghkj.json](/files/commands/full/hgkghkj.json) | JSON | 9 | 0 | 1 | 10 |
| [files/commands/tbl/Get-AzApplicationGateway.json](/files/commands/tbl/Get-AzApplicationGateway.json) | JSON | 5 | 0 | 1 | 6 |
| [files/commands/tbl/Get-AzApplicationGateway1.json](/files/commands/tbl/Get-AzApplicationGateway1.json) | JSON | 5 | 0 | 1 | 6 |
| [files/commands/tbl/hgkghkj.json](/files/commands/tbl/hgkghkj.json) | JSON | 5 | 0 | 1 | 6 |
| [files/configs/codeOrg.json](/files/configs/codeOrg.json) | JSON | 4 | 0 | 0 | 4 |
| [files/configs/startUp.json](/files/configs/startUp.json) | JSON | 0 | 0 | 1 | 1 |
| [files/kql/kqlMeta/sdfgsdfgsdfg.json](/files/kql/kqlMeta/sdfgsdfgsdfg.json) | JSON | 4 | 0 | 1 | 5 |
| [files/powershell/scriptsHTML/Mackenzie(Restored).html](/files/powershell/scriptsHTML/Mackenzie(Restored).html) | HTML | 32 | 0 | 7 | 39 |
| [files/powershell/scriptsMeta/Mackenzie(Restored).json](/files/powershell/scriptsMeta/Mackenzie(Restored).json) | JSON | 9 | 0 | 1 | 10 |
| [files/powershell/scripts/Mackenzie(Restored).ps1](/files/powershell/scripts/Mackenzie(Restored).ps1) | PowerShell | 14 | 8 | 6 | 28 |
| [files/powershell/snippetsMeta/faZcA.json](/files/powershell/snippetsMeta/faZcA.json) | JSON | 6 | 0 | 1 | 7 |
| [files/powershell/snippetsMeta/xVmHr.json](/files/powershell/snippetsMeta/xVmHr.json) | JSON | 7 | 0 | 1 | 8 |
| [files/sql/sqlMeta/Testing portal.json](/files/sql/sqlMeta/Testing%20portal.json) | JSON | 4 | 0 | 1 | 5 |
| [logs/errors/psCodeOrg\_errors\_2025-07-09\_001.log](/logs/errors/psCodeOrg_errors_2025-07-09_001.log) | Log | 42 | 0 | 5 | 47 |
| [logs/errors/psCodeOrg\_errors\_2025-07-10\_001.log](/logs/errors/psCodeOrg_errors_2025-07-10_001.log) | Log | 442 | 0 | 43 | 485 |
| [logs/errors/psCodeOrg\_errors\_2025-07-11\_001.log](/logs/errors/psCodeOrg_errors_2025-07-11_001.log) | Log | 145 | 0 | 16 | 161 |
| [logs/errors/psCodeOrg\_errors\_2025-07-12\_001.log](/logs/errors/psCodeOrg_errors_2025-07-12_001.log) | Log | 189 | 0 | 19 | 208 |
| [logs/errors/psCodeOrg\_errors\_2025-07-14\_001.log](/logs/errors/psCodeOrg_errors_2025-07-14_001.log) | Log | 63 | 0 | 7 | 70 |
| [logs/errors/psCodeOrg\_errors\_2025-07-16\_001.log](/logs/errors/psCodeOrg_errors_2025-07-16_001.log) | Log | 296 | 0 | 27 | 323 |
| [logs/errors/psCodeOrg\_errors\_2025-07-21\_001.log](/logs/errors/psCodeOrg_errors_2025-07-21_001.log) | Log | 212 | 0 | 21 | 233 |
| [logs/errors/psCodeOrg\_errors\_2025-07-22\_001.log](/logs/errors/psCodeOrg_errors_2025-07-22_001.log) | Log | 1,283 | 0 | 125 | 1,408 |
| [logs/errors/psCodeOrg\_errors\_2025-07-23\_001.log](/logs/errors/psCodeOrg_errors_2025-07-23_001.log) | Log | 21 | 0 | 3 | 24 |
| [logs/requests/podeWebDemo\_requests\_2025-05-27\_001.log](/logs/requests/podeWebDemo_requests_2025-05-27_001.log) | Log | 211 | 0 | 1 | 212 |
| [logs/requests/podeWebDemo\_requests\_2025-05-28\_001.log](/logs/requests/podeWebDemo_requests_2025-05-28_001.log) | Log | 1,264 | 0 | 1 | 1,265 |
| [logs/requests/psCodeOrg\_requests\_2025-05-31\_001.log](/logs/requests/psCodeOrg_requests_2025-05-31_001.log) | Log | 525 | 0 | 1 | 526 |
| [logs/requests/psCodeOrg\_requests\_2025-06-01\_001.log](/logs/requests/psCodeOrg_requests_2025-06-01_001.log) | Log | 1,265 | 0 | 1 | 1,266 |
| [logs/requests/psCodeOrg\_requests\_2025-06-02\_001.log](/logs/requests/psCodeOrg_requests_2025-06-02_001.log) | Log | 2,420 | 0 | 1 | 2,421 |
| [logs/requests/psCodeOrg\_requests\_2025-06-03\_001.log](/logs/requests/psCodeOrg_requests_2025-06-03_001.log) | Log | 418 | 0 | 1 | 419 |
| [logs/requests/psCodeOrg\_requests\_2025-06-04\_001.log](/logs/requests/psCodeOrg_requests_2025-06-04_001.log) | Log | 462 | 0 | 1 | 463 |
| [logs/requests/psCodeOrg\_requests\_2025-06-05\_001.log](/logs/requests/psCodeOrg_requests_2025-06-05_001.log) | Log | 397 | 0 | 1 | 398 |
| [logs/requests/psCodeOrg\_requests\_2025-06-06\_001.log](/logs/requests/psCodeOrg_requests_2025-06-06_001.log) | Log | 3,228 | 0 | 1 | 3,229 |
| [logs/requests/psCodeOrg\_requests\_2025-06-07\_001.log](/logs/requests/psCodeOrg_requests_2025-06-07_001.log) | Log | 1,924 | 0 | 1 | 1,925 |
| [logs/requests/psCodeOrg\_requests\_2025-06-08\_001.log](/logs/requests/psCodeOrg_requests_2025-06-08_001.log) | Log | 3,375 | 0 | 1 | 3,376 |
| [logs/requests/psCodeOrg\_requests\_2025-06-09\_001.log](/logs/requests/psCodeOrg_requests_2025-06-09_001.log) | Log | 1,455 | 0 | 1 | 1,456 |
| [logs/requests/psCodeOrg\_requests\_2025-06-10\_001.log](/logs/requests/psCodeOrg_requests_2025-06-10_001.log) | Log | 918 | 0 | 1 | 919 |
| [logs/requests/psCodeOrg\_requests\_2025-06-11\_001.log](/logs/requests/psCodeOrg_requests_2025-06-11_001.log) | Log | 3,951 | 0 | 1 | 3,952 |
| [logs/requests/psCodeOrg\_requests\_2025-06-12\_001.log](/logs/requests/psCodeOrg_requests_2025-06-12_001.log) | Log | 1,318 | 0 | 1 | 1,319 |
| [logs/requests/psCodeOrg\_requests\_2025-06-13\_001.log](/logs/requests/psCodeOrg_requests_2025-06-13_001.log) | Log | 2,257 | 0 | 1 | 2,258 |
| [logs/requests/psCodeOrg\_requests\_2025-06-14\_001.log](/logs/requests/psCodeOrg_requests_2025-06-14_001.log) | Log | 998 | 0 | 1 | 999 |
| [logs/requests/psCodeOrg\_requests\_2025-06-16\_001.log](/logs/requests/psCodeOrg_requests_2025-06-16_001.log) | Log | 2,865 | 0 | 1 | 2,866 |
| [logs/requests/psCodeOrg\_requests\_2025-06-17\_001.log](/logs/requests/psCodeOrg_requests_2025-06-17_001.log) | Log | 2,355 | 0 | 1 | 2,356 |
| [logs/requests/psCodeOrg\_requests\_2025-06-18\_001.log](/logs/requests/psCodeOrg_requests_2025-06-18_001.log) | Log | 2,081 | 0 | 1 | 2,082 |
| [logs/requests/psCodeOrg\_requests\_2025-06-23\_001.log](/logs/requests/psCodeOrg_requests_2025-06-23_001.log) | Log | 2,555 | 0 | 1 | 2,556 |
| [logs/requests/psCodeOrg\_requests\_2025-06-24\_001.log](/logs/requests/psCodeOrg_requests_2025-06-24_001.log) | Log | 1,515 | 0 | 1 | 1,516 |
| [logs/requests/psCodeOrg\_requests\_2025-06-25\_001.log](/logs/requests/psCodeOrg_requests_2025-06-25_001.log) | Log | 3,213 | 0 | 1 | 3,214 |
| [logs/requests/psCodeOrg\_requests\_2025-06-26\_001.log](/logs/requests/psCodeOrg_requests_2025-06-26_001.log) | Log | 1,627 | 0 | 1 | 1,628 |
| [logs/requests/psCodeOrg\_requests\_2025-06-27\_001.log](/logs/requests/psCodeOrg_requests_2025-06-27_001.log) | Log | 98 | 0 | 1 | 99 |
| [logs/requests/psCodeOrg\_requests\_2025-06-29\_001.log](/logs/requests/psCodeOrg_requests_2025-06-29_001.log) | Log | 331 | 0 | 1 | 332 |
| [logs/requests/psCodeOrg\_requests\_2025-06-30\_001.log](/logs/requests/psCodeOrg_requests_2025-06-30_001.log) | Log | 2,404 | 0 | 1 | 2,405 |
| [logs/requests/psCodeOrg\_requests\_2025-07-01\_001.log](/logs/requests/psCodeOrg_requests_2025-07-01_001.log) | Log | 1,287 | 0 | 1 | 1,288 |
| [logs/requests/psCodeOrg\_requests\_2025-07-02\_001.log](/logs/requests/psCodeOrg_requests_2025-07-02_001.log) | Log | 1,051 | 0 | 1 | 1,052 |
| [logs/requests/psCodeOrg\_requests\_2025-07-05\_001.log](/logs/requests/psCodeOrg_requests_2025-07-05_001.log) | Log | 683 | 0 | 1 | 684 |
| [logs/requests/psCodeOrg\_requests\_2025-07-06\_001.log](/logs/requests/psCodeOrg_requests_2025-07-06_001.log) | Log | 1,619 | 0 | 1 | 1,620 |
| [logs/requests/psCodeOrg\_requests\_2025-07-08\_001.log](/logs/requests/psCodeOrg_requests_2025-07-08_001.log) | Log | 535 | 0 | 1 | 536 |
| [logs/requests/psCodeOrg\_requests\_2025-07-09\_001.log](/logs/requests/psCodeOrg_requests_2025-07-09_001.log) | Log | 1,203 | 0 | 1 | 1,204 |
| [logs/requests/psCodeOrg\_requests\_2025-07-10\_001.log](/logs/requests/psCodeOrg_requests_2025-07-10_001.log) | Log | 1,313 | 0 | 1 | 1,314 |
| [logs/requests/psCodeOrg\_requests\_2025-07-11\_001.log](/logs/requests/psCodeOrg_requests_2025-07-11_001.log) | Log | 11 | 0 | 1 | 12 |
| [logs/requests/psCodeOrg\_requests\_2025-07-12\_001.log](/logs/requests/psCodeOrg_requests_2025-07-12_001.log) | Log | 456 | 0 | 1 | 457 |
| [logs/requests/psCodeOrg\_requests\_2025-07-14\_001.log](/logs/requests/psCodeOrg_requests_2025-07-14_001.log) | Log | 2,154 | 0 | 1 | 2,155 |
| [logs/requests/psCodeOrg\_requests\_2025-07-16\_001.log](/logs/requests/psCodeOrg_requests_2025-07-16_001.log) | Log | 648 | 0 | 1 | 649 |
| [logs/requests/psCodeOrg\_requests\_2025-07-21\_001.log](/logs/requests/psCodeOrg_requests_2025-07-21_001.log) | Log | 1,407 | 0 | 1 | 1,408 |
| [logs/requests/psCodeOrg\_requests\_2025-07-22\_001.log](/logs/requests/psCodeOrg_requests_2025-07-22_001.log) | Log | 1,957 | 0 | 1 | 1,958 |
| [logs/requests/psCodeOrg\_requests\_2025-07-23\_001.log](/logs/requests/psCodeOrg_requests_2025-07-23_001.log) | Log | 2,842 | 0 | 1 | 2,843 |
| [modules/Module\_Modals.ps1](/modules/Module_Modals.ps1) | PowerShell | 145 | 17 | 101 | 263 |
| [modules/Module\_Tools.ps1](/modules/Module_Tools.ps1) | PowerShell | 108 | 4 | 41 | 153 |
| [pages/Page\_AboutHelp.ps1](/pages/Page_AboutHelp.ps1) | PowerShell | 5 | 1 | 4 | 10 |
| [pages/Page\_Home.ps1](/pages/Page_Home.ps1) | PowerShell | 53 | 2 | 17 | 72 |
| [pages/Page\_Oops.ps1](/pages/Page_Oops.ps1) | PowerShell | 137 | 4 | 51 | 192 |
| [pages/Page\_codeHub.ps1](/pages/Page_codeHub.ps1) | PowerShell | 312 | 9 | 99 | 420 |
| [pages/Page\_commandDisplay.ps1](/pages/Page_commandDisplay.ps1) | PowerShell | 46 | 1 | 11 | 58 |
| [pages/Page\_commandInput.ps1](/pages/Page_commandInput.ps1) | PowerShell | 45 | 0 | 22 | 67 |
| [pages/Page\_commandUpdate.ps1](/pages/Page_commandUpdate.ps1) | PowerShell | 73 | 1 | 34 | 108 |
| [pages/Page\_formOptions.ps1](/pages/Page_formOptions.ps1) | PowerShell | 120 | 0 | 50 | 170 |
| [pages/Page\_kqlDisplay.ps1](/pages/Page_kqlDisplay.ps1) | PowerShell | 26 | 0 | 10 | 36 |
| [pages/Page\_kqlInput.ps1](/pages/Page_kqlInput.ps1) | PowerShell | 44 | 0 | 21 | 65 |
| [pages/Page\_kqlUpdate.ps1](/pages/Page_kqlUpdate.ps1) | PowerShell | 62 | 0 | 32 | 94 |
| [pages/Page\_psCodePaste.ps1](/pages/Page_psCodePaste.ps1) | PowerShell | 67 | 2 | 26 | 95 |
| [pages/Page\_psCodeUpload.ps1](/pages/Page_psCodeUpload.ps1) | PowerShell | 55 | 2 | 26 | 83 |
| [pages/Page\_psScriptCodeUpdate.ps1](/pages/Page_psScriptCodeUpdate.ps1) | PowerShell | 21 | 0 | 8 | 29 |
| [pages/Page\_psScriptDisplay.ps1](/pages/Page_psScriptDisplay.ps1) | PowerShell | 63 | 1 | 10 | 74 |
| [pages/Page\_psScriptInfoUpdate.ps1](/pages/Page_psScriptInfoUpdate.ps1) | PowerShell | 110 | 1 | 41 | 152 |
| [pages/Page\_snipCodePaste.ps1](/pages/Page_snipCodePaste.ps1) | PowerShell | 46 | 2 | 23 | 71 |
| [pages/Page\_snipDisplay.ps1](/pages/Page_snipDisplay.ps1) | PowerShell | 34 | 1 | 9 | 44 |
| [pages/Page\_snipUpdate.ps1](/pages/Page_snipUpdate.ps1) | PowerShell | 52 | 1 | 28 | 81 |
| [pages/Page\_sqlDisplay.ps1](/pages/Page_sqlDisplay.ps1) | PowerShell | 26 | 0 | 12 | 38 |
| [pages/Page\_sqlInput.ps1](/pages/Page_sqlInput.ps1) | PowerShell | 44 | 0 | 21 | 65 |
| [pages/Page\_sqlUpdate.ps1](/pages/Page_sqlUpdate.ps1) | PowerShell | 62 | 0 | 30 | 92 |
| [pages/Page\_updateCodeOrg.ps1](/pages/Page_updateCodeOrg.ps1) | PowerShell | 5 | 1 | 4 | 10 |
| [public/style.css](/public/style.css) | PostCSS | 22 | 0 | 6 | 28 |
| [server.psd1](/server.psd1) | PowerShell | 29 | 0 | 1 | 30 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)