  #Page information: Home page for Enigma-Tek Code Organizer
     
Set-PodeWebHomePage -NoTitle -Layouts @(

      New-PodeWebHero -Title $SiteName -Message 'by Enigma-Tek' -Content @(
            
            New-PodeWebContainer -Content @(

                  #Update line. Hide unless an update is available, then fill in line on home page load
                  New-PodeWebText -Id 0000 -Value '' -CssClass 'gold'

                  New-PodeWebLine

                  New-PodeWebHeader -Value 'PowerShell, KQL and SQL Code Organizer' -Size 5 -Secondary ''
                  New-PodeWebText -Value "A space for your automation/data scripts and queries" -InParagraph -CssClass 'brightWhite'
                  New-PodeWebText -Value "Organize PowerShell, KQL (Kusto Query Language), and SQL in a centralized repository.
                  Keep your essential scripts, snippets, commands, and queries well-organized and accessible—for personal use or team collaboration." -InParagraph -CssClass 'brightWhite'
                  
                  New-PodeWebLine

                  New-PodeWebText -Value "Click any card below to take you to that part of the Code Hub" -InParagraph -CssClass 'brightWhite' -Alignment Center

                  New-PodeWebGrid -Cells @(
                        New-PodeWebCell -Content @(
                              New-PodeWebTile -Name 'PS script count:' -NoRefresh -ScriptBlock {
                              RETURN (Get-ChildItem -Path "./files/powershell/scripts" -File | Measure-Object | Select-Object -ExpandProperty Count)
                              } -ClickScriptBlock {
                                    Set-PodeCache -Key 'HubTab' -InputObject 000
                                    Move-PodeWebPage -Name 'CodeHub'
                              }
                        )
                        New-PodeWebCell -Content @(
                              New-PodeWebTile -Name 'PS snippet count:' -NoRefresh -ScriptBlock {
                              RETURN (Get-ChildItem -Path "./files/powershell/snippets" -File | Measure-Object | Select-Object -ExpandProperty Count)
                              } -ClickScriptBlock {
                                    Set-PodeCache -Key 'HubTab' -InputObject 501
                                    Move-PodeWebPage -Name 'CodeHub'
                              }
                        )     
                        New-PodeWebCell -Content @(
                              New-PodeWebTile -Name 'KQL code count:' -NoRefresh -ScriptBlock {
                                    RETURN (Get-ChildItem -Path "./files/kql/kqlCode" -File | Measure-Object | Select-Object -ExpandProperty Count)
                              } -ClickScriptBlock {
                                    Set-PodeCache -Key 'HubTab' -InputObject 502
                                    Move-PodeWebPage -Name 'CodeHub'
                              }
                        )
                        New-PodeWebCell -Content @(
                              New-PodeWebTile -Name 'SQL code count:' -NoRefresh -ScriptBlock {
                                    RETURN (Get-ChildItem -Path "./files/sql/sqlCode" -File | Measure-Object | Select-Object -ExpandProperty Count)    
                              } -ClickScriptBlock {
                                    Set-PodeCache -Key 'HubTab' -InputObject 503
                                    Move-PodeWebPage -Name 'CodeHub'
                              }
                        )
                        New-PodeWebCell -Content @(
                              New-PodeWebTile -Name 'Commands count:' -NoRefresh -ScriptBlock {
                                    RETURN (Get-ChildItem -Path "./files/commands/tbl" -File | Measure-Object | Select-Object -ExpandProperty Count)
                              }  -ClickScriptBlock {
                                    Set-PodeCache -Key 'HubTab' -InputObject 504
                                    Move-PodeWebPage -Name 'CodeHub'
                              }
                        )
                         New-PodeWebCell -Content @(
                              New-PodeWebTile -Name 'Link count:' -NoRefresh -ScriptBlock {
                                    RETURN (Get-ChildItem -Path "./files/links" -File | Measure-Object | Select-Object -ExpandProperty Count)
                              }  -ClickScriptBlock {
                                    Set-PodeCache -Key 'HubTab' -InputObject 505
                                    Move-PodeWebPage -Name 'CodeHub'
                              }
                        )

                  )#End grid

                  New-PodeWebLine

                  New-PodeWebHeader -Value 'WARNING - NEVER STORE CREDENTIALS IN CODE!!' -Size 6 -Secondary 'Storing credentials in your code is a bad habit, and a really bad security
                  practice. Doing so can expose your environment. You have been warned.'

            )#End container

      )#End Hero

) -PassThru | Register-PodeWebPageEvent -Type Load -ScriptBlock {

      #The following section gets the version number of the update script and compares it with the local version number. If the online version of the script is greater
      #than the local version, then update script is automatically updated.

      #Get the local version number of the update scripts
      $chkUUpdate = Get-Content "./bin/update/updater.json" | ConvertFrom-Json
      $UupdateVersion = $chkUUpdate.Vers

      #Get the online version number of the update script
      $rawUrl = "https://raw.githubusercontent.com/enigma-tek/PSCodeOrganizer/refs/heads/main/uversion.txt"
      $UGitVerNum = (Invoke-WebRequest -Uri $rawUrl).Content

      #convert both versions into system versions to be able to compare
      $UupdateVersion = [System.Version]$UupdateVersion
      $UGitVerNum = [System.Version]$UGitVerNum

      if ($UupdateVersion -lt $UGitVerNum)  {
            Remove-Item -Path "./bin/update/updater.ps1" -Verbose
            Remove-Item -Path "./bin/update/updater.json" -Verbose
            Invoke-WebRequest -Uri "https://raw.githubusercontent.com/enigma-tek/CodeOrganizer/refs/heads/main/update/updater.ps1" -OutFile "./bin/update/updater.ps1"
            Invoke-WebRequest -Uri "https://raw.githubusercontent.com/enigma-tek/CodeOrganizer/refs/heads/main/update/updater.json" -OutFile "./bin/update/updater.json"
      }    

      #Chk for updates
      $chkUpdate = Get-Content "./files/configs/codeOrg.json" | ConvertFrom-Json
      $updateVersion = $chkUpdate.Vers

      $rawUrl = "https://raw.githubusercontent.com/enigma-tek/PSCodeOrganizer/refs/heads/main/version.txt"
      $GitVerNum = (Invoke-WebRequest -Uri $rawUrl).Content

      $updateVersion = [System.Version]$updateVersion
      $GitVerNum = [System.Version]$GitVerNum

      if ($updateVersion -lt $GitVerNum) {
            Update-PodeWebText -Id 0000 -Value '!! There is an update available for Code Organizer. Use the Update page located under Settings on the left sidebar. !! '
      } Else {}

      #Clean out old log files
      Get-ChildItem "./logs/errors/*.*" | Where-Object LastWriteTime -LT (Get-Date).AddDays(-30) | Remove-Item -Confirm:$false
      Get-ChildItem "./logs/requests/*.*" | Where-Object LastWriteTime -LT (Get-Date).AddDays(-30) | Remove-Item -Confirm:$false

}#End page scriptblock and passthru code block